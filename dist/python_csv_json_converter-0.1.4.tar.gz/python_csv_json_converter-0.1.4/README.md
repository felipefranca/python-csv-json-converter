**CSV TO JSON in Python

Project is written in Python to read a CSV file and export a JSON file. All options to conversion are passed by prompt commands options.
This project makes part of the course Artificial Intelligence, specifically the discipline "Python for data science"
